import java.util.*;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

// FILE: QuestionCollectionTest.java

public class Question {
    private int id;
    private String text;

    public Question(int id, String text) {
        this.id = id;
        this.text = text;
    }

    public int getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    @Override
    public String toString() {
        return "Question ID: " + id + ", Text:" + text;
    }
}

public class QuestionCollection {
    private final Map<Integer, Question> questions = new HashMap<>();

    public boolean addQuestion(int id, String text) {
        if (!ReadInput.validateQuestionText(text)) return false;
        if (questions.containsKey(id)) {
            System.out.println("Error: Question ID already exists.");
            return false;
        }
        
        questions.put(id, new Question(id, text));
        System.out.println("Success: Question added.");
        return true;
    }

    public Question getQuestionID(int id) {
        return questions.getOrDefault(id, null);
    }

    public Collection<Question> getAllQuestions() {
        return questions.values();
    }
}

public class QuestionCollectionTest {
    private QuestionCollection collection;

    @BeforeEach
    void setup() {
        collection = new QuestionCollection();
    }

    @Test
    void testAddValidQuestion() {
        boolean result = collection.addQuestion(1, "What is 2 + 2?");
        assertTrue(result);
        assertNotNull(collection.getQuestionID(1));
    }

    @Test
    void testRetrieveExistingQuestion() {
        collection.addQuestion(1, "What is 2 + 2?");
        Question q = collection.getQuestionID(1);
        assertNotNull(q);
        assertEquals("What is 2 + 2?", q.getText());
    }

    @Test
    void testAddQuestionWithSpecialChars() {
        boolean result = collection.addQuestion(2, "What character is this: @?");
        assertFalse(result);
        assertNull(collection.getQuestionID(2));
    }

    @Test
    void testAddDuplicateId() {
        collection.addQuestion(1, "What is 2 + 2?");
        boolean result = collection.addQuestion(1, "New question?");
        assertFalse(result);
    }

    @Test
    void testAddEmptyQuestion() {
        boolean result = collection.addQuestion(3, "");
        assertFalse(result);
    }

    @Test
    void testTooLongQuestion() {
        String longText = "x".repeat(1000);
        boolean result = collection.addQuestion(4, longText);
        assertFalse(result);
    }

    @Test
    void testGetNonexistentQuestion() {
        Question q = collection.getQuestionID(99999);
        assertNull(q);
    }

    @Test
    void testGetAllQuestions() {
        collection.addQuestion(1, "What is 2 + 2?");
        collection.addQuestion(2, "What is the capital of France?");
        Collection<Question> allQuestions = collection.getAllQuestions();
        assertEquals(2, allQuestions.size());
    }
}