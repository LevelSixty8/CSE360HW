import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the QuestionCollection class.
 * Covers creation and retrieval of questions.
 * 
 * This file is part of HW3 automated testing.
 * Assigned test: testCreateQuestion
 * 
 * @author JJ
 * @version 1.0, 2025-03-25
 */
public class QuestionCollectionTest {

    private QuestionCollection collection;

    @BeforeEach
    void setup() {
        collection = new QuestionCollection();
    }

    /**
     * Automated test case: testCreateQuestion
     * 
     * Verifies that a valid question with a unique ID
     * is correctly added to the QuestionCollection.
     */
    @Test
    void testCreateQuestion() {
        boolean added = collection.addQuestion(1, "What is 2 + 2?");
        Question retrieved = collection.getQuestionID(1);

        assertTrue(added, "Question should be added successfully.");
        assertNotNull(retrieved, "Question should exist after creation.");
        assertEquals(1, retrieved.getId(), "Question ID should match.");
        assertEquals("What is 2 + 2?", retrieved.getText(), "Question text should match.");
    }
}
