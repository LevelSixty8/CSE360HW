public class Answer {
    private final int id;
    private final int questionId;
    private final String text;

    public Answer(int id, int questionId, String text) {
        this.id = id;
        this.questionId = questionId;
        this.text = text;
    }

    public int getId() {
        return id;
    }

    public int getQuestionId() {
        return questionId;
    }

    public String getText() {
        return text;
    }

    @Override
    public String toString() {
        return "Answer ID: " + id + ", Question ID: " + questionId + ", Text: " + text;
    }
}
