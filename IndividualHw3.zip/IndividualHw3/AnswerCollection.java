import java.util.*;

public class AnswerCollection {
    private final Map<Integer, Answer> answers = new HashMap<>();

    public boolean addAnswer(int id, int questionId, String text) {
        if (!ReadInput.validateQuestionText(text)) return false;
        if (answers.containsKey(id)) {
            System.out.println("Error: Answer ID already exists.");
            return false;
        }

        answers.put(id, new Answer(id, questionId, text));
        System.out.println("Success: Answer added.");
        return true;
    }

    public Answer getAnswerById(int id) {
        return answers.getOrDefault(id, null);
    }

    public Collection<Answer> getAllAnswers() {
        return answers.values();
    }
}
